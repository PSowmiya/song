package com.example.demo.Service;

import com.example.demo.Entity.userDetails;



public interface UserService {
	
	public String saveUserDetails(userDetails userDTO) throws  Exception ;
}
